﻿namespace EtsySyncInvoices.Interface
{
    public interface ISalesService
    {
    }
}
