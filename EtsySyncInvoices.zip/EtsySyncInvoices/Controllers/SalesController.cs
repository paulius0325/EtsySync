﻿namespace EtsySyncInvoices.Controllers
{
    public class SalesController
    {
    }
}
