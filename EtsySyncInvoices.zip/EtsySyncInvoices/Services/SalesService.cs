﻿namespace EtsySyncInvoices.Services
{
    public class SalesService
    {
    }
}
