﻿
namespace EtsySyncInvoices.Models
{
    public class Invoice
    {
        public Guid Id { get; set; }
        public string SerialNumber { get; set; } = string.Empty;
        public DateOnly Date { get; set; }
    }
}
