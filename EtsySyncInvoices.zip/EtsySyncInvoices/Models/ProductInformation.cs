﻿namespace EtsySyncInvoices.Models
{
    public class ProductInformation
    {
        public Guid Number { get; set; }
        public string Item {  get; set; } = string.Empty;
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public decimal Amount { get; set; }
        public decimal Total { get; set; }
        public decimal InvoiceTotal { get; set; }
    }
}
