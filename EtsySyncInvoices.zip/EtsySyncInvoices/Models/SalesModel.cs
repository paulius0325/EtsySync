﻿namespace EtsySyncInvoices.Models
{
    public class SalesModel
    {
    }
}
