﻿namespace EtsySyncInvoices.Models
{
    public class Seller
    {
        public string FullName { get; set; } = string.Empty;
        public string IndividualActivities { get; set; } = string.Empty;
        public int CertificateNumber { get; set; }
        public int BusinessCertificateNumber { get; set; }
        public string Address { get; set; } = string.Empty;
        public string Bank { get; set; } = string.Empty;
        public string IBANCode { get; set; } = string.Empty;
    }
}
